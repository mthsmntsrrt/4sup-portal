export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const { pathname } = url;

    // Rotas de API
    if (pathname === "/api/login" && request.method === "POST") {
      return handleLogin(request, env);
    }

    if (pathname === "/api/logout" && request.method === "POST") {
      return handleLogout(request, env);
    }

    // /docs -> protegido
    if (pathname === "/docs" || pathname.startsWith("/docs/")) {
      const sess = await getSession(request, env);
      if (!sess) {
        const loginUrl = new URL("/", url.origin);
        loginUrl.searchParams.set("redirectTo", pathname + url.search);
        return Response.redirect(loginUrl.toString(), 302);
      }

      // Reescrever caminho para dentro do mkdocs_build
      const docsPath = pathname === "/docs"
        ? "/mkdocs_build/"
        : "/mkdocs_build" + pathname.slice("/docs".length);

      const assetUrl = new URL(docsPath + url.search, url.origin);
      // Delegar ao ASSETS para servir o arquivo estático
      return env.ASSETS.fetch(
        new Request(assetUrl.toString(), request)
      );
    }

    // Demais rotas: servir estático normal (index.html, assets, etc)
    return env.ASSETS.fetch(request);
  },
};

// Util: pegar cookie por nome
function getCookie(request, name) {
  const cookieHeader = request.headers.get("Cookie");
  if (!cookieHeader) return null;
  const cookies = cookieHeader.split(";").map((c) => c.trim());
  for (const cookie of cookies) {
    const [k, v] = cookie.split("=");
    if (k === name) return decodeURIComponent(v);
  }
  return null;
}

const SESSION_COOKIE = "docs_session";
const SESSION_TTL_SECONDS = 8 * 60 * 60; // 8h

async function getSession(request, env) {
  const sessId = getCookie(request, SESSION_COOKIE);
  if (!sessId) return null;

  const now = Math.floor(Date.now() / 1000);

  const { results } = await env.DB.prepare(
    "SELECT s.id, s.usuario_id, u.email, u.empresa, u.cnpj \
     FROM sessoes s JOIN usuarios u ON u.id = s.usuario_id \
     WHERE s.id = ? AND s.expira_em > ?"
  )
    .bind(sessId, now)
    .all();

  if (!results || results.length === 0) return null;
  return results[0];
}

async function handleLogin(request, env) {
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "JSON inválido" }, 400);
  }

  const { email, password } = body || {};
  if (!email || !password) {
    return json({ error: "Informe e-mail e senha." }, 400);
  }

  // Atenção: exemplo simples – ideal é guardar hash da senha
  const { results } = await env.DB.prepare(
    "SELECT id, email, senha_hash, empresa, cnpj, ativo \
     FROM usuarios WHERE email = ?"
  )
    .bind(email)
    .all();

  if (!results || results.length === 0) {
    return json({ error: "Credenciais inválidas." }, 401);
  }

  const user = results[0];
  if (!user.ativo) {
    return json({ error: "Usuário inativo." }, 403);
  }

  // Comparação simplificada (NÃO use em produção sem hash)
  if (user.senha_hash !== password) {
    return json({ error: "Credenciais inválidas." }, 401);
  }

  // Criar sessão
  const sessId = crypto.randomUUID();
  const now = Math.floor(Date.now() / 1000);
  const exp = now + SESSION_TTL_SECONDS;

  await env.DB.prepare(
    "INSERT INTO sessoes (id, usuario_id, criado_em, expira_em) VALUES (?, ?, ?, ?)"
  )
    .bind(sessId, user.id, now, exp)
    .run();

  const res = json({ ok: true });
  res.headers.append(
    "Set-Cookie",
    `${SESSION_COOKIE}=${encodeURIComponent(sessId)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${SESSION_TTL_SECONDS}`
  );
  return res;
}

async function handleLogout(request, env) {
  const sessId = getCookie(request, SESSION_COOKIE);
  if (sessId) {
    await env.DB.prepare("DELETE FROM sessoes WHERE id = ?")
      .bind(sessId)
      .run();
  }

  const res = json({ ok: true });
  res.headers.append(
    "Set-Cookie",
    `${SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`
  );
  return res;
}

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" },
  });
}
