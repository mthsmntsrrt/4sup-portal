<div class="hero">
  <span class="badge">Manual Oficial</span>
  <h1>4SUP — Operação de campo sem fricção</h1>
  <p>Portal Web e Aplicativo para planejamento, execução e auditoria das rotas de fiscalização. Integração com GesOper Corporate.</p>
  <div class="actions">
    <<a class="md-button md-button--primary" href="/go/portal_web">Entrar no Portal Web</a>
    <a class="md-button" href="app/">Ver o App</a>
  </div>
</div>
